﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsClass
{
    public class Packages_Products_Suppliers
    {
        public Packages_Products_Suppliers() { }

        public int PaclageID { get; set; }

        public int ProductSupplierID { get; set; }

    }
}
