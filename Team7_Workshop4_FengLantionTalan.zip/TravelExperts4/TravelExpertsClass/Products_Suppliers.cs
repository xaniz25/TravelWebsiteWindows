﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelExpertsClass
{
    public class Products_Suppliers
    {

        public Products_Suppliers() { }

        public int ProductSupplierID { get; set; }

        public int ProductID { get; set; }

        public int SupplierID { get; set; }
    }
}
